import { CustomhoverDirective } from './customhover.directive';

describe('CustomhoverDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomhoverDirective();
    expect(directive).toBeTruthy();
  });
});
